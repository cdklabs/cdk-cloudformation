import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "cdk-cloudformation-tf-ad-user",
    "version": "0.0.0",
    "description": "@cdk-cloudformation/tf-ad-user",
    "license": "Apache-2.0",
    "url": "https://github.com/cdklabs/cdk-cloudformation-types.git",
    "long_description_content_type": "text/markdown",
    "author": "Amazon Web Services",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://github.com/cdklabs/cdk-cloudformation-types.git"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "cdk_cloudformation_tf_ad_user",
        "cdk_cloudformation_tf_ad_user._jsii"
    ],
    "package_data": {
        "cdk_cloudformation_tf_ad_user._jsii": [
            "tf-ad-user@0.0.0.jsii.tgz"
        ],
        "cdk_cloudformation_tf_ad_user": [
            "py.typed"
        ]
    },
    "python_requires": ">=3.6",
    "install_requires": [
        "aws-cdk.core>=0.0.0",
        "constructs>=0.0.0",
        "jsii>=1.39.0, <2.0.0",
        "publication>=0.0.3"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Typing :: Typed",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
